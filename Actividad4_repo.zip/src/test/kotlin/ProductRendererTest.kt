import kotlin.test.Test
import kotlin.test.assertTrue
import kotlin.test.assertEquals

class ProductRendererTest {

    @Test
    fun `render muestra productos cuando la lista no está vacía`() {
        val list = listOf(
            Product(1, "iPhone 13", "The latest iPhone", 999.99, "USD", true),
            Product(2, "Samsung Galaxy S21", "The latest Samsung phone", 899.99, "USD", true)
        )
        val output = ProductRenderer.render(list)
        assertTrue(output.contains("iPhone 13"))
        assertTrue(output.contains("Samsung Galaxy S21"))
    }

    @Test
    fun `render muestra placeholder cuando la lista está vacía`() {
        val output = ProductRenderer.render(emptyList())
        assertEquals("No hay productos disponibles.", output)
    }
}
