object ProductRenderer {
    /**
     * Devuelve un bloque de texto con los productos formateados o un placeholder si la lista está vacía.
     */
    fun render(products: List<Product>): String =
        if (products.isEmpty()) {
            "No hay productos disponibles."
        } else {
            buildString {
                products.forEach { p ->
                    append("${'$'}{p.name} - ${'$'}{p.currency} ${'$'}{"%.2f".format(p.price)}\n")
                }
            }.trimEnd()
        }
}
