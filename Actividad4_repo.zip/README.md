# Actividad 4 — Mobile Testing

Pequeño proyecto Kotlin que implementa un método para renderizar un listado de productos y dos pruebas unitarias:

1. **Cuando hay productos**, se muestra la información en pantalla.  
2. **Cuando la lista está vacía**, se muestra un placeholder.

## Estructura

```
.
├── build.gradle
├── settings.gradle
├── src
    ├── main/kotlin
    │   ├── Product.kt
    │   └── ProductRenderer.kt
    └── test/kotlin
        └── ProductRendererTest.kt
```

## Cómo correr las pruebas

```bash
./gradlew test
```

Requiere JDK 17 o superior y el wrapper de Gradle 8.6+ (se descarga solo la primera vez).
