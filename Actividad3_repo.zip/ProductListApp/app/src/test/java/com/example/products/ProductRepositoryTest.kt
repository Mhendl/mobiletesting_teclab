package com.example.products

import com.example.products.data.ProductDto
import com.example.products.network.ApiService
import com.example.products.repository.ProductRepository
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class ProductRepositoryTest {
    private val api = mockk<ApiService>()
    private val repo = ProductRepository(api)

    @Test
    fun `fetchProducts devuelve lista no vacía`() = runTest {
        val fake = listOf(
            ProductDto(
                1,
                "Zapatilla",
                "Comoda",
                99.9,
                ""
            )
        )
        coEvery { api.getProducts() } returns fake

        val result = repo.fetchProducts()

        assertEquals(1, result.size)
        coVerify(exactly = 1) { api.getProducts() }
    }
}
