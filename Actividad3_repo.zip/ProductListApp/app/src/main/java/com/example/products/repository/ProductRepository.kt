package com.example.products.repository

import com.example.products.data.ProductDto
import com.example.products.network.ApiService

class ProductRepository(private val api: ApiService) {
    suspend fun fetchProducts(): List<ProductDto> = api.getProducts()
    suspend fun fetchProduct(id: Int): ProductDto = api.getProduct(id)
}
