package com.example.products.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.products.viewmodel.ProductViewModel

@Composable
fun ProductDetailScreen(id: Int, nav: NavController, vm: ProductViewModel) {
    var product by remember { mutableStateOf<com.example.products.data.ProductDto?>(null) }

    LaunchedEffect(id) { product = vm.repo.fetchProduct(id) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(product?.title ?: "Detalle") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Atrás")
                    }
                }
            )
        }
    ) { padding ->
        product?.let { p ->
            Column(
                Modifier
                    .padding(padding)
                    .padding(16.dp)
            ) {
                AsyncImage(
                    model = p.image,
                    contentDescription = p.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                )
                Spacer(Modifier.height(16.dp))
                Text(p.title, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text(p.description)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Precio: $${p.price}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        } ?: Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    }
}
