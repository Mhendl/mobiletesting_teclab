package com.example.products.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.products.viewmodel.ProductViewModel
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items

@Composable
fun ProductListScreen(nav: NavController, vm: ProductViewModel) {
    val list by vm.products.collectAsState()

    LaunchedEffect(Unit) { vm.load() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Productos") }) }
    ) { padding ->
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(Modifier.padding(padding)) {
                items(list) { p ->
                    ListItem(
                        headlineContent = { Text(p.title) },
                        supportingContent = { Text("$${p.price}") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { nav.navigate("detail/${p.id}") }
                    )
                    Divider()
                }
            }
        }
    }
}
