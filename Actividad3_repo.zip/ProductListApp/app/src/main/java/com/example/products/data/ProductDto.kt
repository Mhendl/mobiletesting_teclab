package com.example.products.data

data class ProductDto(
    val id: Int,
    val title: String,
    val description: String,
    val price: Double,
    val image: String,
    val rating: Rating = Rating()
) {
    data class Rating(val rate: Double = 0.0, val count: Int = 0)
}
