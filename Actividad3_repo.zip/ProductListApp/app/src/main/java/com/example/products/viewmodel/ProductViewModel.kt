package com.example.products.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.products.data.ProductDto
import com.example.products.network.ApiClient
import com.example.products.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ProductViewModel(
    val repo: ProductRepository = ProductRepository(ApiClient.api)
) : ViewModel() {

    private val _products = MutableStateFlow<List<ProductDto>>(emptyList())
    val products = _products.asStateFlow()

    fun load() = viewModelScope.launch {
        _products.value = repo.fetchProducts()
    }
}
