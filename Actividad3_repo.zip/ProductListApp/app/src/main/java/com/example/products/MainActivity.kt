package com.example.products

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.navigation.compose.*
import com.example.products.ui.ProductDetailScreen
import com.example.products.ui.ProductListScreen
import com.example.products.viewmodel.ProductViewModel

class MainActivity : ComponentActivity() {
    private val vm by lazy { ProductViewModel() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val nav = rememberNavController()
                NavHost(nav, startDestination = "list") {
                    composable("list") { ProductListScreen(nav, vm) }
                    composable("detail/{id}") { back ->
                        val id = back.arguments?.getString("id")!!.toInt()
                        ProductDetailScreen(id, nav, vm)
                    }
                }
            }
        }
    }
}
