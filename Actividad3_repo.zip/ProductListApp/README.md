# ProductListApp

Demo Android (Kotlin + Jetpack Compose) que consume [FakeStoreAPI](https://fakestoreapi.com/) para listar productos.

## Requisitos
- JDK 17
- Android Studio Flamingo (o más reciente)
- Gradle Wrapper (incluido)

## Cómo correr
```bash
git clone <TU-REPO>
cd ProductListApp
./gradlew installDebug   # o simplemente F5 desde Android Studio
```

## Pruebas unitarias + cobertura
```bash
./gradlew testDebugUnitTest jacocoTestReport
# Reporte HTML: app/build/reports/jacoco/test/html/index.html
```

## Estructura
- `data` modelos DTO
- `network` Retrofit
- `repository` capa de dominio
- `viewmodel` estados UI
- `ui` pantallas Compose

## Licencia
MIT
